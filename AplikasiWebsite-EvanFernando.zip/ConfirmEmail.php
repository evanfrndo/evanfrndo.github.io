<?php

include('config.php');

 if (isset($_GET['code'])) { 

    $code =  $_GET['code'];

    $sql = "SELECT * FROM admin WHERE verif_code = '$code'";

    $query = mysqli_query($conn,$sql);

    if(mysqli_num_rows($query) > 0) {
   
        
        $user = mysqli_fetch_assoc($query);
        $id= $user ['id'];

        $sql = "UPDATE admin SET is_verif=1 WHERE id=$id";

        $query = mysqli_query($conn,$sql);

        if ($query) {
            echo "<script>alert('Email berhasil terverifikasi, silahkan login ke akun anda !');document.location.href='index.php';</script>";
        } else {
            echo "<script>alert('Maaf Verifikasi Gagal silahkan coba ulang kembali !')</script>".$query;
        }

    }else {
        echo "<script>alert('Code Tidak Ditemukan Atau Tidak Valid !')</script>";
    }


    } else {
        echo "Tidak ada code";
    }


?>