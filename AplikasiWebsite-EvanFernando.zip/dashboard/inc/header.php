<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="inc/style.css">

    <link rel="icon" href="inc/img/logo.jpg">

    <!-- font awesome-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">

    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <title>PerbanasXcitiasia</title>
</head>

<body>

    <!-- menu navigation kiri -->

    <section id="menu">

        <div class="logo">
            <?php
             include('process/config.php');   $email = $_SESSION['email']; ?>
            <img src="inc/img/logo.jpg" alt="">
            <h5 style="font-size:13px"> <?php echo $email; ?> </h5>
        </div>

        <div class="items">
            <li class="<?php if ($page == 'dashboard') { echo 'active';} ?>"><i class="fas fa-chart-bar"><a href="index.php"> Dashboard </a></i></li>
            <li class="<?php if ($page == 'kategori') { echo 'active';} ?>"><i class="fas fa-layer-group"><a href="kategori.php"> Kategori Barang </a></i></li>
            <li class="<?php if ($page == 'stok') { echo 'active';} ?>"><i class="fas fa-cubes"><a href="stok.php"> Stok Barang </a></i></li>
            <li class="<?php if ($page == 'pemasukan') { echo 'active';} ?>"><i class="fas fa-sign-out-alt"><a href="pemasukan.php"> Pemasukan </a></i></li>
            <li class="<?php if ($page == 'kontrol') { echo 'active';} ?>"><i class="fas fa-cogs"><a href="kontrol.php"> Kontrol Akun </a></i></li>
        </div>

    </section>

    <!-- menu navigation kiri -->



    <!-- navigation atas -->

    <section id="interface">

        <div class="navigation">

            <div class="n1">


                <!-- mennu bar mobile -->


                <div>
                    <i id="menu-btn" class="fas fa-bars"></i>
                </div>


                <!-- mennu bar mobile -->

                <div class="search">
                    Manajemen Toko System
                </div>
            </div>

            <div class="profile">
                <a href="logout.php" style="text-decoration: none;">Sign Out</a>
            </div>

        </div>

        </div>


