<?php

session_start();

$email = $_SESSION['email'];

$page = 'dashboard';

//membuat jika session berhasil berjalan

include('../config.php');

include('inc/header.php');

$get1 = mysqli_query($conn, "SELECT * FROM staff ");
$count1 = mysqli_num_rows($get1);

$get2 = mysqli_query($conn, "SELECT * FROM staff WHERE posisi='KaryawanToko'");
$count2 = mysqli_num_rows($get2);

$get3 = mysqli_query($conn, "SELECT * FROM staff WHERE posisi='Operator'");
$count3 = mysqli_num_rows($get3);

$get4 = mysqli_query($conn, "SELECT * FROM staff WHERE posisi='Kurir'");
$count4 = mysqli_num_rows($get4);

$penjumlahan = "SELECT SUM(harga_barang) AS sum FROM pemasukan";

$query_result = mysqli_query($conn, $penjumlahan);

while ($row = mysqli_fetch_assoc($query_result)) {
    $output = $row['sum'];
}


?>


<!-- judul isi -->

<h3 class="i-name">
    Dashboard
</h3>

<!-- judul isi -->





<!-- card -->

<div class="values">




    <div class="val-box">
        <i class="fas fa-users"></i>
        <div>
            <h3><?php echo $output; ?></h3>
            <span>Balance Kas</span>
        </div>
    </div>

    <div class="val-box">
        <i class="fas fa-users"></i>
        <div>
            <h3><?php echo $count1 ?></h3>
            <span>Total Staff</span>
        </div>
    </div>

    <div class="val-box">
        <i class="fas fa-users"></i>
        <div>
            <h3><?php echo $count2 ?></h3>
            <span>Penjaga Toko</span>
        </div>
    </div>

    <div class="val-box">
        <i class="fas fa-users"></i>
        <div>
            <h3><?php echo $count3 ?></h3>
            <span>Operator</span>
        </div>
    </div>



</div>

<!-- card -->
<hr>

<div>
    <h2 class="text-center mt-3" style="font-weight: bold;">Cabang Toko </h2>
</div>


<!-- table daftar cabang -->

<div class="values">

    <div class="val-box-toko">
        <div>
            <h5>Jakarta Selatan</h5>
            <hr>
            <p>Graha Mustika Ratu 5th Floor Graha Mustika Ratu Jalan Gatot Subroto #503, RT.2/RW.1, Menteng Dalam, Tebet, South Jakarta City, Jakarta 12870</p>
        </div>
    </div>

    <div class="val-box-toko">
        <div>
            <h5>Jakarta Timur</h5>
            <hr>
            <p>Graha Mustika Ratu 5th Floor Graha Mustika Ratu Jalan Gatot Subroto #503, RT.2/RW.1, Menteng Dalam, Tebet, East Jakarta City, Jakarta 12870</p>
        </div>
    </div>

    <div class="val-box-toko">
        <div>
            <h5>Jakarta Utara</h5>
            <hr>
            <p>Graha Mustika Ratu 5th Floor Graha Mustika Ratu Jalan Gatot Subroto #503, RT.2/RW.1, Menteng Dalam, Tebet, North Jakarta City, Jakarta 12870</p>
        </div>
    </div>

    <div class="val-box-toko">
        <div>
            <h5>Jakarta Barat</h5>
            <hr>
            <p>Graha Mustika Ratu 5th Floor Graha Mustika Ratu Jalan Gatot Subroto #503, RT.2/RW.1, Menteng Dalam, Tebet, West Jakarta City, Jakarta 12870</p>
        </div>
    </div>

</div>


<!-- table daftar cabang -->

<div>
    <h2 class="text-center mt-3" style="font-weight: bold;">Daftar Staff</h2>
</div>

<!-- table staff -->

<div class="board">

    <button type="button" data-toggle="modal" data-target="#form-modal" class="btn btn-dark mb-1 mt-3 ml-2"> Tambah Data Staff + </button>

    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Staff</th>
            <th>Penempatan Cabang Staff</th>
            <th>Posisi</th>
            <th>Shift Jam Kerja</th>
            <th>Tanggal Masuk</th>
            <th>Aksi</th>
        </tr>

        <?php

        $no = 1;

        //membuat variable yang berisi ambil data dari category 
        $query = mysqli_query($conn, "SELECT * FROM staff");

        //membuat loop ketika artinya perumpamaan 
        while ($row = mysqli_fetch_assoc($query)) {

        ?>

            <tr class="text-center">
                <td><?php echo $no++;  ?></td>
                <td><?php echo $row['nama_staff']; ?></td>
                <td><?php echo $row['penempatan']; ?></td>
                <td><?php echo $row['posisi']; ?></td>
                <td><?php echo $row['shift_kerja']; ?></td>
                <td><?php echo $row['tgl_masuk']; ?></td>
                <td>
                    <a onclick="return confirm('Yakin Ingin Menghapus barang Ini ?');" href="process/hapus_karyawan.php?id=<?php echo $row['id']; ?>" class="btn btn-dark btn-sm">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <hr>

    <h5> Total Staff : </h5>

</div>


<!-- table -->




<?php

include('inc/footer.php');

?>




<!-- modal -->

<div class="modal" id="form-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Form Tambah Data Staff </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="process/save_karyawan.php" method="post">
                    <div class="form-group">
                        <label for="nama_staff">Nama Staff : </label>
                        <input type="text" name="nama_staff" id="nama_staff" class="form-control" placeholder="Silahkan isi nama staff" required>
                    </div>
                    <div class="form-group">
                        <label for="penempatan">Penempatan Kerja : </label>
                        <select name="penempatan" id="penempatan" class="form-control">
                            <option value="JakartaSelatan">Jakarta Selatan</option>
                            <option value="JakartaTimur">Jakarta Timur</option>
                            <option value="JakartaUtara">Jakarta Utara</option>
                            <option value="JakartaBarat">Jakarta Barat</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="posisi"> Posisi : </label>
                        <select name="posisi" id="posisi" class="form-control">
                            <option value="Operator">Operator</option>
                            <option value="KaryawanToko">KaryawanToko</option>
                            <option value="Kurir">Kurir</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Shift_kerja"> Shift Jam Kerja : </label>
                        <select name="shift_kerja" id="shift_kerja" class="form-control">
                            <option value="06.00 - 12.00">06.00 - 12.00</option>
                            <option value="12.00 - 18.00">12.00 - 18.00 </option>
                            <option value="06.00 - 18.00">06.00 - 18.00</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tgl_masuk">Tanggal Masuk : </label>
                        <input type="date" name="tgl_masuk" id="tgl_masuk" class="form-control" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                </form>

            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
            </div>
        </div>
    </div>
</div>


<!-- modal -->