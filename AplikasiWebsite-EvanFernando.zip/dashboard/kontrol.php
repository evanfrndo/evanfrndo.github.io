<?php

session_start();

$page = 'kontrol';

//membuat jika session berhasil berjalan

include('../config.php');

include('inc/header.php');

$get1 = mysqli_query($conn, "SELECT * FROM admin");
$count1 = mysqli_num_rows($get1);

$get2 = mysqli_query($conn, "SELECT * FROM operator");
$count2 = mysqli_num_rows($get2);


?>


<!-- judul isi -->

<h3 class="i-name">
    Tabel Kontrol Akun
</h3>


<!-- table Kategori -->

<div class="board">


    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Administrator</th>
            <th>Email</th>
            <th>Level</th>
            <th>Aksi</th>
        </tr>

        <?php

        $no = 1;

        //membuat variable yang berisi ambil data dari category 
        $query = mysqli_query($conn, "SELECT * FROM admin");

        //membuat loop ketika artinya perumpamaan 
        while ($row = mysqli_fetch_assoc($query)) {

        ?>

            <tr class="text-center">
                <td><?php echo $no++;  ?></td>
                <td><?php echo $row['nama']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['level']; ?></td>
                <td>
                    <a onclick="return confirm('Yakin Ingin Menghapus Kategori Ini ?');" href="process/hapus_admin.php?id=<?php echo $row['id']; ?>" class="btn btn-dark btn-sm">Hapus</a>
                </td>
            </tr>

        <?php } ?>
    </table>

    <hr>

    <h5> Total Admin : <?php echo $count1 ?> </h5>

</div>


<!-- table Kategori -->

<!-- table Kategori -->

<div class="board">


    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Operator</th>
            <th>Email</th>
            <th>Level</th>
            <th>Aksi</th>
        </tr>

        <?php

        $no = 1;

        //membuat variable yang berisi ambil data dari category 
        $query = mysqli_query($conn, "SELECT * FROM operator");

        //membuat loop ketika artinya perumpamaan 
        while ($row = mysqli_fetch_assoc($query)) {

        ?>

            <tr class="text-center">
                <td><?php echo $no++;  ?></td>
                <td><?php echo $row['nama']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['level']; ?></td>
                <td>
                    <a onclick="return confirm('Yakin Ingin Menghapus Kategori Ini ?');" href="process/hapus_operator.php?id=<?php echo $row['id']; ?>" class="btn btn-dark btn-sm">Hapus</a>
                </td>
            </tr>

        <?php } ?>
    </table>

    <hr>

    <h5> Total Operator : <?php echo $count1 ?> </h5>

</div>


<!-- table Kategori -->




<?php

include('inc/footer.php');


?>