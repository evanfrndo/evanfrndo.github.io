<?php

session_start();

$page = 'pemasukan';

//membuat jika session berhasil berjalan

include('../config.php');

include('inc/header.php');

$penjumlahan= "SELECT SUM(harga_barang) AS sum FROM pemasukan";

$query_result= mysqli_query($conn,$penjumlahan);

while ($row = mysqli_fetch_assoc($query_result)) {
    $output = $row['sum'];
}

?>


<!-- judul isi -->

<h3 class="i-name">
    Daftar Pemasukan Toko
</h3>


<!-- table stok barang -->

<div class="board">

    <button type="button" data-toggle="modal" data-target="#form-modal" class="btn btn-dark mb-1 mt-3 ml-2"> Tambah Data Pemasukan + </button>


    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori Barang</th>
            <th>Jumlah Barang</th>
            <th>Harga Total</th>
            <th>Cabang Pemasukan dari toko</th>
            <th>Tanggal Pemasukan</th>
            <th>Aksi</th>
        </tr>

        <?php

        $no = 1;

        //membuat variable yang berisi ambil data dari category 
        $query = mysqli_query($conn, "SELECT * FROM pemasukan");

        //membuat loop ketika artinya perumpamaan 
        while ($row = mysqli_fetch_assoc($query)) {

        ?>

            <tr class="text-center">
                <td><?php echo $no++;  ?></td>
                <td><?php echo $row['nama_barang']; ?></td>
                <td><?php echo $row['kategori_nama']; ?></td>
                <td><?php echo $row['jumlah_barang']; ?></td>
                <td><?php echo $row['harga_barang']; ?></td>
                <td><?php echo $row['cabang_toko']; ?></td>
                <td><?php echo $row['tgl_pemasukan']; ?></td>
                <td>
                    <a onclick="return confirm('Yakin Ingin Menghapus Data pemasukan Ini ?');" href="process/hapus_pemasukan.php?id=<?php echo $row['id']; ?>" class="btn btn-dark btn-sm">Hapus</a>
                </td>
            </tr>

        <?php } ?>
    </table>

    <hr>

    <h5>Total pemasukann : <?php echo $output; ?> </h5>

</div>



<?php

include('inc/footer.php');

?>



<!-- modal -->

<div class="modal" id="form-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Form Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="process/save_pemasukan.php" method="post">
                    <div class="form-group">
                        <label for="nama_barang">Nama Barang : </label>
                        <input type="text" name="nama_barang" id="nama_barang" class="form-control" placeholder="Silahkan isi nama barang" required>
                    </div>
                    <div class="form-group">
                        <label for="kategori_nama">Nama Kategori : </label>
                        <select name="kategori_nama" class="form-control">
                            <!-- buat looping dl untuk memanggil option kategori dari database kategori -->
                            <?php


                            $query = "SELECT * FROM kategori";

                            $cek_query = mysqli_query($conn, $query);

                            //while berfungsi untuk menanpilkan data berulang
                            while ($row = mysqli_fetch_assoc($cek_query)) { ?>

                                <option value="<?php echo $row['kategori_nama'] ?>"><?php echo $row['kategori_nama']; ?></option>

                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_barang">Jumlah Barang : </label>
                        <input type="number" name="jumlah_barang" id="jumlah_barang" class="form-control" placeholder="Silahkan isi jumlah barang" required>
                    </div>
                    <div class="form-group">
                        <label for="harga_barang">Harga Total : </label>
                        <input type="number" name="harga_barang" id="harga_barang" class="form-control" placeholder="Silahkan isi harga barang" required>
                    </div>
                    <div class="form-group">
                        <label for="cabang_toko">Cabang Toko : </label>
                        <select name="cabang_toko" id="cabang_toko" class="form-control">
                            <option value="JakartaSelatan">Jakarta Selatan</option>
                            <option value="JakartaTimur">Jakarta Timur</option>
                            <option value="JakartaUtara">Jakarta Utara</option>
                            <option value="JakartaBarat">Jakarta Barat</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tgl_pemasukan">Tanggal Pemasukan : </label>
                        <input type="date" name="tgl_pemasukan" id="tgl_pemasukan" class="form-control" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                </form>

            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
            </div>
        </div>
    </div>
</div>


<!-- modal -->