<?php

session_start();

$page = 'pengeluaran';

//membuat jika session berhasil berjalan

include('../config.php');

include('inc/header.php');

?>


<!-- judul isi -->

<h3 class="i-name">
    Daftar Pengeluaran Toko
</h3>


<!-- table stok barang -->

<div class="board">

    <a href="form_berita.php" type="button" class="btn btn-dark mb-1 mt-3 ml-2"> Tambah data pengeluaran kas + </a>

    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori Barang</th>
            <th>Jumlah Barang</th>
            <th>Cabang Pemasukan dari toko</th>
            <th>Aksi</th>
        </tr>

        <tr class="text-center">
            <td>1</td>
            <td>Batu</td>
            <td>Material</td>
            <td>100</td>
            <td>Jakarta Timur</td>
            <td>
                <a href="edit"> Edit | </a>
                <a href="hapus"> Hapus</a>
            </td>
        </tr>
    </table>

    <hr>

    <h5>Total pengeluaran : </h5>

</div>




<?php

include('inc/footer.php');

?>