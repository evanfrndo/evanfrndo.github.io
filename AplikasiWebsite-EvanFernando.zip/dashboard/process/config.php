<?php

$conn = mysqli_connect("localhost","root","","toko") or die ("ERROR CONNECTION");

?>