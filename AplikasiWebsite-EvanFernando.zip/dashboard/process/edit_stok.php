 <?php

    session_start();

    $page = 'kontrol';

    //membuat jika session berhasil berjalan

    include('config.php');

    include('inc/header.php');



    ?>


 <form action="process/save_kategori.php" method="post">
     <div class="form-group">
         <label for="nama">Nama Kategori : </label>
         <input type="text" name="kategori_nama" id="nama" class="form-control" placeholder="Silahkan isi kategori" required>
     </div>
     <div class="form-group">
         <label for="tgl">Tanggal Penambahan : </label>
         <input type="date" name="tgl" id="tgl" class="form-control" required>
     </div>
     <button type="submit" name="submit" class="btn btn-primary">Save</button>
 </form>


 <?php

    include('inc/footer.php');


    ?>