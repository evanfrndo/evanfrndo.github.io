<?php

include('config.php');

if (!isset($_GET['id'])) {
    header("location: ../kontrol.php");
    exit();
} else {
    $id = $_GET['id'];
    $query = "DELETE FROM operator WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        echo "<script> alert ('Data Berhasil Dihapus');document.location.href ='../index.php'; </script>";
        exit();
    } else {
        echo "<script> alert ('Data Gagal Dihapus');document.location.href ='../index.php'; </script>";
        exit();
    }
}
