<?php

include('config.php');

if (isset($_POST['submit'])) {
    $nama_staff = $_POST['nama_staff'];
    $penempatan = $_POST['penempatan'];
    $posisi = $_POST['posisi'];
    $shift_kerja = $_POST['shift_kerja'];
    $tgl_masuk = $_POST['tgl_masuk'];


    $query = mysqli_query($conn, "INSERT INTO staff(nama_staff,penempatan,posisi,shift_kerja,tgl_masuk) VALUES ('$nama_staff','$penempatan','$posisi','$shift_kerja','$tgl_masuk')");

    if ($query) {
        echo "<script> alert ('Data Staff berhasil ditambahkan');document.location.href = '../index.php'; </script>";
    } else {
        echo "<script> alert ('Data Staff gagal ditambahkan, mohon periksa kembali !');document.location.href = '../index.php'; </script>";
    }
}
