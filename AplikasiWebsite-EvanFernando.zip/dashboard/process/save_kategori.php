<?php

include('config.php');

//membuat fungsi jika tombol submit ditekan

//membuat fungsi jika tombol submit ditekan
if (isset($_POST['submit'])) {

    //membuar variable untuk category dan des
    $kategori_nama = $_POST['kategori_nama'];
    $tgl = $_POST['tgl'];


        //membuat query  untuk masukan ke dalam database
        $query = mysqli_query($conn, "INSERT INTO kategori(kategori_nama,tgl) VALUES ('$kategori_nama','$tgl')");

        if ($query) {
            echo "<script> alert ('Kategori Berhasil Ditambahkan');document.location.href = '../kategori.php'; </script>";
        } else {
            echo "<script> alert ('Mohon Pastikan Semua terisi') </script>";
        }
    }


?>
