<?php

include('config.php');

if (isset($_POST['submit'])) {
    $nama_barang = $_POST['nama_barang'];
    $kategori_nama = $_POST['kategori_nama'];
    $jumlah_barang = $_POST['jumlah_barang'];
    $harga_barang = $_POST['harga_barang'];
    $cabang_toko = $_POST['cabang_toko'];
    $tgl_pemasukan = $_POST['tgl_pemasukan'];


    $query = mysqli_query($conn, "INSERT INTO pemasukan(nama_barang,kategori_nama,jumlah_barang,harga_barang,cabang_toko,tgl_pemasukan) VALUES ('$nama_barang','$kategori_nama','$jumlah_barang','$harga_barang','$cabang_toko','$tgl_pemasukan')");

    if ($query) {
        echo "<script> alert ('Data Pemasukan berhasil ditambahkan');document.location.href = '../pemasukan.php'; </script>";
    } else {
        echo "<script> alert ('Data Pemasukan gagal ditambahkan, mohon periksa kembali !');document.location.href = '../pemasukan.php'; </script>";
    }
}
