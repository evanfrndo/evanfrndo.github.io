<?php

include('config.php');

if (isset($_POST['submit'])) {
    $nama_barang = $_POST['nama_barang'];
    $kategori_nama = $_POST['kategori_nama'];
    $jumlah = $_POST['jumlah'];
    

    $query = mysqli_query($conn, "INSERT INTO stok(nama_barang,kategori_nama,jumlah) VALUES ('$nama_barang','$kategori_nama','$jumlah')");

    if ($query) {
        echo "<script> alert ('Data barang berhasil ditambahkan');document.location.href = '../stok.php'; </script>";
    } else {
        echo "<script> alert ('Data barang gagal ditambahkan, mohon periksa kembali !');document.location.href = '../kategori.php'; </script>";
    }
}
