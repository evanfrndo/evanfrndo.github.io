<?php

session_start();

$page = 'kategori';

//membuat jika session berhasil berjalan

include('../config.php');

include('inc/header.php');

$get1 = mysqli_query($conn,"SELECT * FROM kategori");
$count1 = mysqli_num_rows($get1);

?>


<!-- judul isi -->

<h3 class="i-name">
    Daftar Kategori Barang
</h3>


<!-- table Kategori -->

<div class="board">

    <button type="button" data-toggle="modal" data-target="#form-modal" class="btn btn-dark mb-1 mt-3 ml-2"> Tambah Data Kategori + </button>

    <table width="100%" style="margin-top: 5px;">
        <hr>
        <tr class="text-center">
            <th>No</th>
            <th>Nama Kategori</th>
            <th>Tanggal Penambahan</th>
            <th>Aksi</th>
        </tr>

        <?php

        $no = 1;

        //membuat variable yang berisi ambil data dari category 
        $query = mysqli_query($conn, "SELECT * FROM kategori");

        //membuat loop ketika artinya perumpamaan 
        while ($row = mysqli_fetch_assoc($query)) {

        ?>

            <tr class="text-center">
                <td><?php echo $no++;  ?></td>
                <td><?php echo $row['kategori_nama']; ?></td>
                <td><?php echo $row['tgl']; ?></td>
                <td>
                    <a onclick="return confirm('Yakin Ingin Menghapus Kategori Ini ?');" href="process/hapus_kategori.php?id=<?php echo $row['kategori_id']; ?>" class="btn btn-dark btn-sm">Hapus</a>
                </td>
            </tr>

        <?php } ?>
    </table>

    <hr>

    <h5> Total Kategori : <?php echo $count1 ?> </h5>

</div>


<!-- table Kategori -->


<?php

include('inc/footer.php');

?>


<!-- modal -->

<div class="modal" id="form-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Form Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="process/save_kategori.php" method="post">
                    <div class="form-group">
                        <label for="nama">Nama Kategori : </label>
                        <input type="text" name="kategori_nama" id="nama" class="form-control" placeholder="Silahkan isi kategori" required>
                    </div>
                    <div class="form-group">
                        <label for="tgl">Tanggal Penambahan : </label>
                        <input type="date" name="tgl" id="tgl" class="form-control" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                </form>

            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
            </div>
        </div>
    </div>
</div>


<!-- modal -->