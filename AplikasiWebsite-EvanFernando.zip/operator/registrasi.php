<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


    <link rel="icon" href="img/logo.jpg">

    <link rel="stylesheet" href="assets/style.css">

    <title>Registrasi</title>

</head>

<body class="bg-gradient">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center" style="margin-top: 15px; margin-left: -15px ;">

            <!-- card -->

            <div class="card" style="width: 45rem;">
                <div class="card-body">

                    <div class="container">
                        <div class="row text-center">
                            <div class="col-md-12 text-center">
                                <h4> Aplikasi Manajemen Data Kampus Berbasis Website </h4>
                            </div>
                            <div class="col-md-6">
                                <img src="img/logo.jpg" alt="" width="100%">
                            </div>
                            <div class="col-md-6 formsregist">
                                <form action="prosesregister.php" method="post">
                                    <div class="form-group">
                                        <h2>Registrasi</h2>
                                        <hr>
                                    </div>
                                    <div class="form-group">
                                        <div style="border: 1px solid grey; padding:5px;">
                                            <a href="#" style="color: grey; text-decoration:none;">Operator</a>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="nama">Nama</label>
                                        <input type="text" name="nama" id="nama" placeholder="" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="text" name="email" id="email" placeholder="" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" id="password" placeholder="" class="form-control">
                                    </div>
                                    <div>
                                        <a href="index.php">Sudah punya akun ?</a>
                                    </div>

                                    <button style="color: white; background-color: blue; width: 100px; height: 40px;" type="submit" name="register">DAFTAR</button>

                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- card -->

        </div>
    </div>

    <div class="text-center mt-1">Developer : Evan Fernando</div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>



</body>

</html>