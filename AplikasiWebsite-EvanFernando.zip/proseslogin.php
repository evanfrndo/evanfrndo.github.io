<?php


session_start();

include('config.php');

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM admin WHERE email='$email'";



$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query) == 0) {
    echo "<script>alert('Email atau Password salah !');document.location.href='index.php';</script>";
} else {
    $user = mysqli_fetch_assoc($query);
    if (password_verify($password, $user['password'])) {
        if ($user['is_verif'] == 1) {
            //membuat sesi
            $_SESSION['id_user'] = $user['id'];
            $_SESSION['email'] = $email;
            //jika berhasil loginkan ke home.php
            header('location:  dashboard/index.php');
        }  {
            echo "<script>alert('Verifikasi Email Terlebih Dahulu !');document.location.href='index.php';</script>";
        }
    } else {
        echo "<script>alert('Email atau Password salah !');document.location.href='index.php';</script>";
    }
}






?>
